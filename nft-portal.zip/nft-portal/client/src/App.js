import { useState, useEffect } from "react";
import { Button, Card, Form, Image, Modal } from "react-bootstrap";
import "./App.css";
import contract from "./nft";

function App() {
  const [account, setAccount] = useState("");
  const [hasMinted, setHasMinted] = useState(false);
  const [hasMintingPeriodEnded, setHasMintingPeriodEnded] = useState(false);
  const [nfts, setNFTs] = useState([]);
  const [showModal, setShowModal] = useState(false);
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [image, setImage] = useState("");

  useEffect(() => {
    async function fetchAccount() {
      const accounts = await window.ethereum.request({
        method: "eth_accounts"
      });
      setAccount(accounts[0]);
    }
    fetchAccount();
  }, []);

  useEffect(() => {
    async function fetchNFTs() {
      const nftCount = await contract.methods.totalSupply().call();
      const nfts = [];
      for (let i = 0; i < nftCount; i++) {
        const tokenId = await contract.methods.tokenByIndex(i).call();
        const metadata = await contract.methods.getNFTMetadata(tokenId).call();
        nfts.push({ tokenId, metadata });
      }
      setNFTs(nfts);
    }
    fetchNFTs();
  }, [hasMinted]);

  useEffect(() => {
    async function checkMintingPeriod() {
      const now = new Date();
      const mintingPeriodStart = new Date("2023-02-20T00:00:00Z");
      const mintingPeriodEnd = new Date("2023-03-02T23:59:59Z");
      setHasMintingPeriodEnded(now > mintingPeriodEnd);
    }
    checkMintingPeriod();
  }, []);

  const handleMintNFT = async () => {
    const now = new Date();
    const mintingPeriodStart = new Date("2023-02-20T00:00:00Z");
    const mintingPeriodEnd = new Date("2023-03-02T23:59:59Z");
    if (now < mintingPeriodStart) {
      alert("Minting period has not started yet.");
      return;
    } else if (now > mintingPeriodEnd) {
      alert("Minting period has ended.");
      return;
    }

    const nftCount = await contract.methods.balanceOf(account).call();
    if (nftCount >= 5) {
      alert("You have already minted 5 NFTs.");
      return;
    }

    const hasAlreadyMinted = await contract.methods.hasMintedNFT(account).call();
    if (hasAlreadyMinted) {
      alert("You have already minted an NFT.");
      return;
    }

    await contract.methods.mintNFT(name, description, image).send({ from: account });
    setHasMinted(true);
    setShowModal(false);
  };

  const handleCloseModal = () => {
    setShowModal(false);
  };

  const handleOpenModal = () => {
    setShowModal(true);
  };

  const handleNameChange = (event) => {
    setName(event.target.value);
  };

  const handleDescriptionChange = (event) => {
    setDescription(event.target.value);
  };

  const handleImageChange = (event) => {
    setImage(event.target.value);
  };
    
  return (
      <div className="App">
        <header className="App-header">
          <h1>NFT Portal</h1>
          {account ? (
            <div>
              <p>Connected Account: {account}</p>
              <Button variant="primary" onClick={handleOpenModal} disabled={hasMinted || hasMintingPeriodEnded}>
                Mint NFT
              </Button>
            </div>
          ) : (
            <p>Please connect to a wallet to interact with the NFT portal.</p>
          )}
        </header>
        <main>
          <div className="nfts-container">
            {nfts.map((nft) => (
              <Card key={nft.tokenId} className="nft-card">
                <Image src={nft.metadata.image} className="nft-image" />
                <Card.Body>
                  <Card.Title>{nft.metadata.name}</Card.Title>
                  <Card.Text>{nft.metadata.description}</Card.Text>
                </Card.Body>
              </Card>
            ))}
          </div>
        </main>
        <Modal show={showModal} onHide={handleCloseModal}>
          <Modal.Header closeButton>
            <Modal.Title>Mint NFT</Modal.Title>
          </Modal.Header>
          <Modal.Body>
            <Form>
              <Form.Group>
                <Form.Label>Name</Form.Label>
                <Form.Control type="text" placeholder="Enter name" value={name} onChange={handleNameChange} />
              </Form.Group>
              <Form.Group>
                <Form.Label>Description</Form.Label>
                <Form.Control type="text" placeholder="Enter description" value={description} onChange={handleDescriptionChange} />
              </Form.Group>
              <Form.Group>
                <Form.Label>Image URL</Form.Label>
                <Form.Control type="text" placeholder="Enter image URL" value={image} onChange={handleImageChange} />
              </Form.Group>
            </Form>
          </Modal.Body>
          <Modal.Footer>
            <Button variant="secondary" onClick={handleCloseModal}>
              Close
            </Button>
            <Button variant="primary" onClick={handleMintNFT}>
              Mint
            </Button>
          </Modal.Footer>
        </Modal>
      </div>
    );
  }
export default App;
  